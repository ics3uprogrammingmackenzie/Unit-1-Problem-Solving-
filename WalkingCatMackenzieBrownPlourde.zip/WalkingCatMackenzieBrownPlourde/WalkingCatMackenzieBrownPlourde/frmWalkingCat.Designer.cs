﻿namespace WalkingCatMackenzieBrownPlourde
{
    partial class frmWalkingCat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picCat1 = new System.Windows.Forms.PictureBox();
            this.btnWalk1 = new System.Windows.Forms.Button();
            this.btnWalk2 = new System.Windows.Forms.Button();
            this.picCat2 = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCat1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCat2)).BeginInit();
            this.SuspendLayout();
            // 
            // picCat1
            // 
            this.picCat1.Image = global::WalkingCatMackenzieBrownPlourde.Properties.Resources.cat2;
            this.picCat1.Location = new System.Drawing.Point(226, 156);
            this.picCat1.Name = "picCat1";
            this.picCat1.Size = new System.Drawing.Size(326, 241);
            this.picCat1.TabIndex = 0;
            this.picCat1.TabStop = false;
            this.picCat1.Click += new System.EventHandler(this.picCat_Click);
            // 
            // btnWalk1
            // 
            this.btnWalk1.Location = new System.Drawing.Point(226, 80);
            this.btnWalk1.Name = "btnWalk1";
            this.btnWalk1.Size = new System.Drawing.Size(75, 23);
            this.btnWalk1.TabIndex = 1;
            this.btnWalk1.Text = "Walk 1";
            this.btnWalk1.UseVisualStyleBackColor = true;
            this.btnWalk1.Click += new System.EventHandler(this.btnWalk1_Click);
            // 
            // btnWalk2
            // 
            this.btnWalk2.Location = new System.Drawing.Point(477, 80);
            this.btnWalk2.Name = "btnWalk2";
            this.btnWalk2.Size = new System.Drawing.Size(75, 23);
            this.btnWalk2.TabIndex = 2;
            this.btnWalk2.Text = "Walk 2";
            this.btnWalk2.UseVisualStyleBackColor = true;
            this.btnWalk2.Click += new System.EventHandler(this.button2_Click);
            // 
            // picCat2
            // 
            this.picCat2.Image = global::WalkingCatMackenzieBrownPlourde.Properties.Resources.cat1;
            this.picCat2.Location = new System.Drawing.Point(226, 156);
            this.picCat2.Name = "picCat2";
            this.picCat2.Size = new System.Drawing.Size(326, 241);
            this.picCat2.TabIndex = 3;
            this.picCat2.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(713, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmWalkingCat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.picCat2);
            this.Controls.Add(this.btnWalk2);
            this.Controls.Add(this.btnWalk1);
            this.Controls.Add(this.picCat1);
            this.Name = "frmWalkingCat";
            this.Text = "Walking Cat";
            ((System.ComponentModel.ISupportInitialize)(this.picCat1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCat2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picCat1;
        private System.Windows.Forms.Button btnWalk1;
        private System.Windows.Forms.Button btnWalk2;
        private System.Windows.Forms.PictureBox picCat2;
        private System.Windows.Forms.Button btnExit;
    }
}

