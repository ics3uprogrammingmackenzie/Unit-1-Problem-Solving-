﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Created by: Mackenzie Brown Plourde
 * Created on: 16 03 2019
 * Created for: ICS3U Programming
 * Daily Assignment – Day #8 - Walking Cat
 * This program Changes the picture on screen with the click of a button
*/
namespace WalkingCatMackenzieBrownPlourde
{
    public partial class frmWalkingCat : Form
    {
        public frmWalkingCat()
        {// Hides both picCat1 and picCat2
            InitializeComponent();
            picCat1.Hide();
            picCat2.Hide();
        }

        private void picCat_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Shows picCat2 and Hides picCat1
            picCat2.Show();
            picCat1.Hide();
        }

        private void btnWalk1_Click(object sender, EventArgs e)
        {
            //Hides picCat2 and Shows PicCat1
            picCat1.Show();
            picCat2.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
