﻿namespace AreaMackenzieBrownPlourde
{
    partial class Areafrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLength = new System.Windows.Forms.Label();
            this.lblWidth = new System.Windows.Forms.Label();
            this.txtLenght = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.lblArea1 = new System.Windows.Forms.Label();
            this.lblArea2 = new System.Windows.Forms.Label();
            this.lblPerimeter1 = new System.Windows.Forms.Label();
            this.lblPerimeter2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblLength
            // 
            this.lblLength.AutoSize = true;
            this.lblLength.Location = new System.Drawing.Point(34, 21);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(74, 13);
            this.lblLength.TabIndex = 0;
            this.lblLength.Text = "Type in lenght";
            // 
            // lblWidth
            // 
            this.lblWidth.AutoSize = true;
            this.lblWidth.Location = new System.Drawing.Point(34, 83);
            this.lblWidth.Name = "lblWidth";
            this.lblWidth.Size = new System.Drawing.Size(70, 13);
            this.lblWidth.TabIndex = 1;
            this.lblWidth.Text = "Type in width";
            // 
            // txtLenght
            // 
            this.txtLenght.Location = new System.Drawing.Point(155, 18);
            this.txtLenght.Name = "txtLenght";
            this.txtLenght.Size = new System.Drawing.Size(100, 20);
            this.txtLenght.TabIndex = 2;
            this.txtLenght.TextChanged += new System.EventHandler(this.txtLenght_TextChanged);
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(155, 76);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(100, 20);
            this.txtWidth.TabIndex = 3;
            // 
            // lblArea1
            // 
            this.lblArea1.AutoSize = true;
            this.lblArea1.Location = new System.Drawing.Point(73, 238);
            this.lblArea1.Name = "lblArea1";
            this.lblArea1.Size = new System.Drawing.Size(63, 13);
            this.lblArea1.TabIndex = 4;
            this.lblArea1.Text = "The area is:";
            // 
            // lblArea2
            // 
            this.lblArea2.AutoSize = true;
            this.lblArea2.Location = new System.Drawing.Point(220, 238);
            this.lblArea2.Name = "lblArea2";
            this.lblArea2.Size = new System.Drawing.Size(35, 13);
            this.lblArea2.TabIndex = 5;
            this.lblArea2.Text = "label2";
            this.lblArea2.Click += new System.EventHandler(this.lblArea2_Click);
            // 
            // lblPerimeter1
            // 
            this.lblPerimeter1.AutoSize = true;
            this.lblPerimeter1.Location = new System.Drawing.Point(69, 316);
            this.lblPerimeter1.Name = "lblPerimeter1";
            this.lblPerimeter1.Size = new System.Drawing.Size(85, 13);
            this.lblPerimeter1.TabIndex = 6;
            this.lblPerimeter1.Text = "The perimeter is:";
            // 
            // lblPerimeter2
            // 
            this.lblPerimeter2.AutoSize = true;
            this.lblPerimeter2.Location = new System.Drawing.Point(220, 316);
            this.lblPerimeter2.Name = "lblPerimeter2";
            this.lblPerimeter2.Size = new System.Drawing.Size(35, 13);
            this.lblPerimeter2.TabIndex = 7;
            this.lblPerimeter2.Text = "label4";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(713, 21);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(311, 152);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 9;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // Areafrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblPerimeter2);
            this.Controls.Add(this.lblPerimeter1);
            this.Controls.Add(this.lblArea2);
            this.Controls.Add(this.lblArea1);
            this.Controls.Add(this.txtWidth);
            this.Controls.Add(this.txtLenght);
            this.Controls.Add(this.lblWidth);
            this.Controls.Add(this.lblLength);
            this.Name = "Areafrm";
            this.Text = "Area and perimeter By Mackenzie Brown Plourde";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLength;
        private System.Windows.Forms.Label lblWidth;
        private System.Windows.Forms.TextBox txtLenght;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.Label lblArea1;
        private System.Windows.Forms.Label lblArea2;
        private System.Windows.Forms.Label lblPerimeter1;
        private System.Windows.Forms.Label lblPerimeter2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
    }
}

