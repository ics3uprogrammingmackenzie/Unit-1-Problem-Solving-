﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Created by: Mackenzie Brown Plourde
 * Created on: 16 03 2019
 * Created for: ICS3U Programming
 * Daily Assignment – Day #9 - Area and Perimeter
 * This program Calculates Area and Perimeter
*/
namespace AreaMackenzieBrownPlourde
{
    public partial class Areafrm : Form
    {
        public Areafrm()
        {
            //Hides lables
            InitializeComponent();
            lblArea1.Hide();
            lblArea2.Hide();
            lblPerimeter1.Hide();
            lblPerimeter2.Hide();

           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exits app on click
            Application.Exit();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {//Shows lables
            lblArea1.Show();
            lblArea2.Show();
            lblPerimeter1.Show();
            lblPerimeter2.Show();
            //Defines variables
            double Lenght, Width, Area, Perimeter;
            //Sets variables
            Lenght = double.Parse(txtLenght.Text);
            Width = double.Parse(txtWidth.Text);
            
            //Formula
             Area = Lenght * Width;
            
            Perimeter = (Lenght * Width) * (2);
            //Shows Answer
            this.lblArea2.Text = Convert.ToString(Area) + " squared meters";
            this.lblPerimeter2.Text = Convert.ToString(Perimeter) + " meters";
        }

        private void txtLenght_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblArea2_Click(object sender, EventArgs e)
        {

        }
    }
}
